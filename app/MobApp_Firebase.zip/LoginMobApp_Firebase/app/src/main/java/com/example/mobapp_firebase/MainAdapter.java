package com.example.mobapp_firebase;
import com.firebase

public class MainAdapter extends FirebaseRecyclerAdapter{
}
