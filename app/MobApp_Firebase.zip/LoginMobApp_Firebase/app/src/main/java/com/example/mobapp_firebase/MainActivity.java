package com.example.mobapp_firebase;

import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    Button btnLogOut;
    FirebaseAuth mAuth;
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // pour eluminer la bar audessus
        //getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN , WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);

        btnLogOut = findViewById(R.id.btnLogout);
        mAuth = FirebaseAuth.getInstance();


        //////////////
        ////////////
        //////////
        ////////
        //////
        ////
        ///
        //RECYCLEVIEW
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));




        //////////////
        ////////////
        //////////
        ////////
        //////
        ////
        ///
        //

//        ListView listView = (ListView)findViewById(R.id.listView);
//
//        //
//
//        UserAccount tom = new UserAccount("Tom","admin");
//        UserAccount jerry = new UserAccount("Jerry","user");
//        UserAccount donald = new UserAccount("Donald","guest", false);
//
//        UserAccount[] users = new UserAccount[]{tom,jerry, donald};
//
//
//        // android.R.layout.simple_list_item_1 is a constant predefined layout of Android.
//        // used to create a ListView with simple ListItem (Only one TextView).
//
//        ArrayAdapter<UserAccount> arrayAdapter
//                = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, users);
//
//        listView.setAdapter(arrayAdapter);

        //
        ///
        ////
        //////
        ////////
        //////////
        ////////////
        //////////////


        btnLogOut.setOnClickListener(view ->{
            mAuth.signOut();
            setContentView(R.layout.activity_login);
            startActivity(new Intent(this, LoginActivity.class));
        });

    }


    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser user = mAuth.getCurrentUser();
        if (user == null){
            startActivity(new Intent(this, LoginActivity.class));
        }
    }
}

